/*Names: Mustafa, Ali, Mehmet
 * Class: PROG24178 1231_18326, Winter 2023
 * Assignment: Project – Employee Management
 * Date: April 10, 2023
 * Program: EmployeeSearch.java
 * This is class handling different search categories
 */
package java2_project_khan_manzani_sakalli;

import java.util.ArrayList;

public class EmployeeSearch {
    //load employees to array list
    private static ArrayList < Employee > employeeList = EmployeeIO
        .loadEmployees();

    //no arg constructor
    public EmployeeSearch(EmployeeController employeeController) {

    }

    public static ArrayList < Employee > searchById(int id) {
        ArrayList < Employee > result = new ArrayList < >
    (); //new arraylist to store result
        for (Employee employee:
            employeeList) { // for each loop to check for matches
            if (employee.getId() == id) {
                result.add(employee);
                break; // assuming ID is unique, we can stop searching once we find a match
            }
        }
        return result;
    }

    public static ArrayList < Employee > searchByJobTitle(String jobTitle) {
        ArrayList < Employee > result = new ArrayList < > ();
        for (Employee employee:
            employeeList) { //for each loop to check for matches
            if (employee.getJob().equalsIgnoreCase(jobTitle)) {
                result.add(employee); //add employee if match found
            }
        }
        return result;
    }

    public static ArrayList < Employee > searchByFullTimeStatus(
        boolean isFullTime) {
        ArrayList < Employee > result = new ArrayList < > ();
        for (Employee employee:
            employeeList) { //for each loop to check for matches
            if (employee.isFullTime() == isFullTime) {
                result.add(employee); //add employee if match found
            }
        }
        return result;
    }

    public static ArrayList < Employee > searchByGender(String gender) {
        ArrayList < Employee > result = new ArrayList < > ();
        for (Employee employee:
            employeeList) { //for each loop to check for matches
            if (employee.getGender().equalsIgnoreCase(gender)) {
                result.add(employee); //add employee if match found
            }
        }
        return result;
    }

} //end of class