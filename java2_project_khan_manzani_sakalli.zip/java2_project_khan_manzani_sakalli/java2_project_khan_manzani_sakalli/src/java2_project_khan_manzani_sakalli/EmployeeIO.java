/*Names: Mustafa, Ali, Mehmet
 * Class: PROG24178 1231_18326, Winter 2023
 * Assignment: Project – Employee Management
 * Date: April 10, 2023
 * Program: EmployeeIO.java
 * This is the IO class that is responsible for file read and write
 */
package java2_project_khan_manzani_sakalli;

import java.io.*;
import java.util.ArrayList;

public class EmployeeIO {
    private static final String FILENAME =
    "EmployeeDatabase.csv"; //assign name of file 

    private static final File FILE = new File(
    FILENAME); //creates a new file with FILENAME

    public EmployeeIO() {
        createNewFile();
    }

    private static void createNewFile() {
        if (!FILE.exists()) { //creates file if it does not exist
            try {
                FILE.createNewFile();
            } catch (IOException e) {}
        }
    }

    //method for save to file button
    public static void saveEmployees(ArrayList < Employee > employees) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(
            FILE))) {
            for (Employee e:
                employees) { //for each loop to iteratre through all employees 
                writer.write(e.getId() + "," + e.getName() + "," + e
                    .getJob() + "," + e.isFullTime() + "," + e
                    .getGender());
                writer.newLine();
            }
        } catch (IOException ex) {}
    }

    //method to load employees
    public static ArrayList < Employee > loadEmployees() {
        ArrayList < Employee > employees = new ArrayList < > ();
        try (BufferedReader reader = new BufferedReader(new FileReader(
            FILE))) {
            String line;
            while ((line = reader.readLine()) !=
                null) { //while loop to read each line
                String[] fields = line.split(","); //split into fields
                //reads respective employee attributes and adds to array list
                employees.add(new Employee(Integer.parseInt(fields[0]),
                    fields[1],
                    fields[2], Boolean.parseBoolean(fields[3]),
                    fields[4]));
            }
        } catch (IOException ex) {}
        return employees;
    }

} //end of class