/*Names: Mustafa, Ali, Mehmet
 * Class: PROG24178 1231_18326, Winter 2023
 * Assignment: Project – Employee Management
 * Date: April 10, 2023
 * Program: EmployeeController.java
 * This is the controller class that will handle the logic for GUI
 */
package java2_project_khan_manzani_sakalli;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;

public class EmployeeController implements Initializable {
    @FXML
    private ListView < Employee > employeeListView = new ListView < > ();

    @FXML
    private Label numEmployeesLabel;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnDel;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnSearch;

    @FXML
    private CheckBox checkBoxFulltime;

    @FXML
    private ComboBox < String > comboBoxJob;

    @FXML
    private ComboBox < String > comboBoxSearch;

    @FXML
    private RadioButton radioFemale;

    @FXML
    private RadioButton radioMale;

    @FXML
    private RadioButton radioOther;

    @FXML
    private TextField tfId;

    @FXML
    private TextField tfName;

    @FXML
    private TextField tfSearchId;

    @FXML
    private Button btnClear;

    @FXML
    private Label lblErrorId;

    @FXML
    private Label lblErrorName;

    @FXML
    private Label lblErrorGender;

    @FXML
    private Label lblErrorJob;

    @FXML
    private Label lblSearchError;

    @FXML
    private Button btnClearSearch;

    @FXML
    private Label tfError;

    //declaring array list for the employees to show on the listView
    private ArrayList < Employee > currentEmployees = new ArrayList < > ();

    //boolean to check if user saves to file or not
    static boolean savedChanges = true;

    //create instance of EmployeeIO class
    EmployeeIO ei = new EmployeeIO();

    //implements initialize interface for when application is started
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        currentEmployees = ei
            .loadEmployees(); //loads employees from a CSV to the listView
        displayEmployeeListView();
        ToggleGroup tg = new ToggleGroup();
        tg.getToggles().addAll(radioMale, radioFemale,
            radioOther); //group all radio buttons

        //job titles 
        comboBoxJob.getItems().addAll("Manager", "Sales", "Accounting",
            "Marketing",
            "Human Resources", "Information Technology");

        //search options
        comboBoxSearch.getItems().addAll("Female", "Male", "Other",
            "Manager", "Sales",
            "Accounting", "Marketing", "Human Resources",
            "Information Technology", "Full Time", "ID");

        tfSearchId.setVisible(false);
        btnClearSearch.setVisible(false);

    }

    public void updateEmployeeListView(ArrayList < Employee > employees) {
        //clears the listView
        employeeListView.getItems().clear();

        // add the new list of employees to the employee list view
        employeeListView.getItems().addAll(employees);
    }

    /* 
    This method is for handling the add employee button,
    it has several validation checks for empty fields, 
    number format for the id, positive integer checks, etc.
    */
    @FXML
    private void handleAddEmployeeButton(ActionEvent event) {

        savedChanges = false;
        String idString = tfId.getText(); //assign the id to String
        String name = tfName.getText(); //assign name to String

        //check for the fulltime checkbox
        boolean isFullTime = checkBoxFulltime.isSelected();

        //gender logic
        String gender = ""; //assings gender to chosen radio button
        if (radioMale.isSelected()) {
            gender = "Male";
        } else if (radioFemale.isSelected()) {
            gender = "Female";
        } else if (radioOther.isSelected()) {
            gender = "Other";
        }

        // validate input
        boolean isValid = true;

        if (idString.isEmpty()) { //validation incase id is left empty
            lblErrorId.setText("ID is required.");
            isValid = false;
        } else {
            try {
                int id = Integer.parseInt(idString);
                lblErrorId.setText(""); //valid

                if (id < 0) { //validation to check if ID is positive
                    lblErrorId.setText("ID must be positive");
                    isValid = false;
                }

               if(currentEmployees.stream().anyMatch(e -> e.getId()==id)){  
                    lblErrorId.setText("This ID already exists");
                    isValid = false;
                }
            } catch (
                NumberFormatException e
            ) { // error handling to catch if the id is not a number
                lblErrorId.setText("ID must be a number.");
                isValid = false; //sets bool to false if conditions not met
            }
        }

        if (name.isEmpty()) { //validation for empty name
            lblErrorName.setText("Name is required.");
            isValid = false;
        }

        if (!name.isEmpty()) {
            lblErrorName.setText(""); //valid
        }

        SingleSelectionModel < String > selectionModel = comboBoxJob
            .getSelectionModel();
        String selectedJob = selectionModel.getSelectedItem();
        if (selectedJob == null) { //validation if job is left empty
            lblErrorJob.setText("Job title is required.");
            isValid = false;
        }

        if (selectedJob != null) {
            lblErrorJob.setText(""); //valid
        }

        if (gender.isEmpty()) { //validation if gender is left empty
            lblErrorGender.setText("Gender is required.");
            isValid = false;
        }

        if (!gender.isEmpty()) {
            lblErrorGender.setText(""); //valid
        }

        if (!
            isValid
        ) { //opens an alert window for possible errors using the bool isValid
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.showAndWait();
            return;
        }

        int id = Integer.parseInt(idString); //parses the String to int

        //assign variables to Employee constructer 
        Employee employee = new Employee(id, name, selectedJob, isFullTime,
            gender);
        currentEmployees.add(employee); //adds the employee to listView
        displayEmployeeListView(); //updates the listView

        // Clear input fields after pressing add
        tfId.setText("");
        tfName.setText("");
        comboBoxJob.getSelectionModel().clearSelection();
        checkBoxFulltime.setSelected(false);
        radioMale.setSelected(false);
        radioFemale.setSelected(false);
        radioOther.setSelected(false);
    }

    /*
    This is the remove employee buttons method which simply 
    gets the selected employee from the list view and removes it 
    using .remove, and the list view is then updated to show the 
    changes.
    */
    @FXML
    private void handleRemoveEmployeeButton(ActionEvent event) {
        savedChanges = false;
        Employee selectedEmployee = employeeListView.getSelectionModel()
            .getSelectedItem();
        if (selectedEmployee == null) { //validation
            tfError.setText("Please select an employee first");
            return;
        }

        boolean removed = currentEmployees.remove(
            selectedEmployee); //removes employee from arraylist
        tfError.setText("");
        if (removed) {
            displayEmployeeListView
                (); //update the listview by refreshing the arraylist
        } else {}
    }

    /*
    This method handles the save to file button and it simply checks
    if it is already saved and shows a label saying no need to save.
    Other wise it will save the current employee list to the CSV
    */
    @FXML
    private void handleSaveToFileButton(ActionEvent event) {
        if (savedChanges != false) {
            tfError.setText("No need to save");
        } else {
            EmployeeIO.saveEmployees(
                currentEmployees); //calls a method to save
            savedChanges = true;
            tfError.setText("");
        }
    }

    /*
    This class is responsible for handling all the search features like 
    search for manager, gender, etc. It has various validation implementations
    and also displays the number of the result subset employees and total number 
    of employees. 
    */
    @FXML
    public void handleSearchButton(ActionEvent event) {
        try {
            displayEmployeeListView
                (); //update the search listview incase new employees are added

            if (savedChanges == false) { //validation (need to save)
                numEmployeesLabel.setText(
                    "Save the changes before searching");

            } else {

                String selectedCriteria = comboBoxSearch.getValue();
                ArrayList < Employee > searchResults = new ArrayList < > ();

                //search logic for genders
                if (selectedCriteria.equals("Female") || selectedCriteria
                    .equals("Male") || selectedCriteria.equals("Other")) {
                    searchResults = EmployeeSearch.searchByGender(
                        selectedCriteria
                    ); //calls method to search by gender
                    numEmployeesLabel.setText(
                        "Number of Employees in this subset: " + String
                        .valueOf(searchResults.size())
                    ); //shows number of employees in subset
                    btnClearSearch.setVisible(
                        true
                    ); //clear button is visible incase user wants to see original list view
                    tfSearchId.setVisible(false);
                    lblSearchError.setText("");


                    //search logic for fulltime
                } else if (selectedCriteria.equals("Full Time")) {
                    searchResults = EmployeeSearch.searchByFullTimeStatus(
                        true); //calls method to search for fulltime
                    numEmployeesLabel.setText(
                        "Number of Employees in this subset: " + String
                        .valueOf(searchResults.size()));
                    tfSearchId.setVisible(false);
                    lblSearchError.setText("");

                    //search logic job title
                } else if (selectedCriteria.equals("Manager") ||
                    selectedCriteria.equals("Sales") || selectedCriteria
                    .equals("Accounting") ||
                    selectedCriteria.equals("Human Resources") ||
                    selectedCriteria.equals("Information Technology") ||
                    selectedCriteria.equals("Marketing")) {
                    searchResults = EmployeeSearch.searchByJobTitle(
                        selectedCriteria); //calls method to search by job
                    numEmployeesLabel.setText(
                        "Number of Employees in this subset: " + String
                        .valueOf(searchResults.size()));
                    btnClearSearch.setVisible(true);
                    tfSearchId.setVisible(false);
                    lblSearchError.setText("");

                    //search logic for ID
                } else if (selectedCriteria.equals("ID")) {

                    //initiate another try block for error handling
                    try {
                        tfSearchId.setVisible(
                            true); //text field is set to visible for input
                        numEmployeesLabel.setText(
                            "Number of Employees in this subset: " +
                            String.valueOf(searchResults.size()));
                        btnClearSearch.setVisible(true);
                        String idToSearch = tfSearchId.getText();
                        int idToSearch1 = Integer.parseInt(
                            idToSearch); //parse String to int 
                        searchResults = EmployeeSearch.searchById(
                            idToSearch1
                        ); //calls method to search for given id
                        lblSearchError.setText("");
                        numEmployeesLabel.setText(
                            "Number of Employees in this subset: " +
                            String.valueOf(searchResults.size()));
                        //validation incase no ID is found
                        if (EmployeeSearch.searchById(idToSearch1)
                            .isEmpty()) {
                            lblSearchError.setText("ID not found");
                        }

                    } catch (
                        NumberFormatException e
                    ) { //validation if ID is not a number
                        lblSearchError.setText("ID must be Integer");
                    }
                }

                displaySearchResult(searchResults);
            }

            //validation incase user does not select an option from combo box
        } catch (NullPointerException e) {
            lblSearchError.setText("Please select an option first");
        }

    }

    /*
    This is the method to clear the GUI and essentially start fresh like 
    when you first launch the app. It sets all the fields to null and all error
    labels to empty string.
    */
    @FXML
    void handleClearButton(ActionEvent event) {
        //set all error lables, selections, inputs, and clear them
        radioMale.setSelected(false);
        radioFemale.setSelected(false);
        radioOther.setSelected(false);
        tfId.setText("");
        tfName.setText("");
        checkBoxFulltime.setSelected(false);
        comboBoxJob.setValue(null);
        comboBoxSearch.setValue(null);
        tfSearchId.setVisible(false);
        lblErrorGender.setText("");
        lblErrorId.setText("");
        lblErrorJob.setText("");
        lblErrorName.setText("");
        lblSearchError.setText("");
        btnClearSearch.setVisible(false);
        tfError.setText("");
        displayEmployeeListView(); //refreshes the listView as well
    }

    /*
    This is the method to display the employees in list view. It simply clears
    the entire list view first and then re adds them using a for each loop
    and also shows the total number of employees using a label.
    */
    @FXML
    private void displayEmployeeListView() {
        //clears the listView
        employeeListView.getItems().clear();

        //for each loop to add each employee essentially updating listView
        for (Employee employee: currentEmployees) {
            employeeListView.getItems().add(employee);
        }

        // label to set the number of employees
        numEmployeesLabel.setText("Number of Employees: " + String.valueOf(
            currentEmployees.size()));

    }

    /*
    This method is responsible to displaying the search result when the user
    performs a search, it first clears list view and re adds new employees based
    on the selected criteria.
    */
    private void displaySearchResult(ArrayList < Employee > searchResults) {
        //clear the entire listView
        employeeListView.getItems().clear();

        //only add employees from searchResults to listView 
        for (Employee employee: searchResults) {
            employeeListView.getItems().add(employee);
        }
    }

} //end of class