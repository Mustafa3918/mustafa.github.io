/*Names: Mustafa, Ali, Mehmet
* Class: PROG24178 1231_18326, Winter 2023
* Assignment: Project – Employee Management
* Date: April 10, 2023
* Program: Employee.java
* This is a class that defines an employee
*/

package java2_project_khan_manzani_sakalli;

public class Employee {
    private int id;
    private String name;
    private String job;
    private boolean fullTime;
    private String gender;

//all arg constructor
    public Employee(int id, String name, String job, boolean fullTime, String gender) { 
        this.id = id;
        this.name = name;
        this.job = job;
        this.fullTime = fullTime;
        this.gender = gender;
    }

// getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public boolean isFullTime() {
        return fullTime;
    }

    public void setFullTime(boolean fullTime) {
        this.fullTime = fullTime;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

// toString method to be used to display for the listview
    @Override
    public String toString() {
        return 
            " Id='" + getId() + " " +
            ", Name='" + getName() + " " +
            ", Job='" + getJob() + " " +
            ", FullTime='" + isFullTime() + " " +
            ", Gender='" + getGender() + " ";
    }    

} //end of class
